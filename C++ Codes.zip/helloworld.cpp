// First c++ program

#include<iostream>
int main()
{
  std::cout << "Hello World!" << std::endl;

  return 0; //always return 0 when using int(main)
  //std::cout << " " << std::endl used for printing
}
