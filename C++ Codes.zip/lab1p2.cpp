#include <iostream>
using namespace std;
//this is for lab 1 part 2
//what will happen is this is for a coin eater program
int main()
{

  //variables
  double q,n,d,p,fee,total;
  //q=quarter price
  //n=nickle price
  //d=dime price
  //p=penny price
  //total= total amount without the fee
  int a,b,c,e,payout;
  //a= amount of quarters user has
  //b= amount of nickles user has
  //c=amount of dimes you have
  //d=amount of pennies you have
  //payout = the total user has

  double h,i,j,k;//for the $amount for  each coin

  //setting variable prices
  q=.25;
  n=.05;
  d=.10;
  p=.01; 
  
  //Coding starts
  cout<<"Welcome to the Coin Eater Program"<<endl;

  //amount of coins the user has 
  cout<<"Please enter the amount of Quarters you have: "<<endl;
  cin>>a;//user's input for the quarters

  cout<<"Please enter the amount of Dimes you have: "<<endl;
  cin>>c;//amount of dimes someone has

  cout<<"Please enter the amount of nickles you have: "<<endl;
  cin>>b;//amount of nickles the user has

  cout<<"Please enter the amount of pennies you have: "<<endl;
  cin>>e;

  h=q*a;//quarter $
  i=d*c;//dime $
  j=n*b;//nickle $
  k=p*e;//pennie $

  //printing the amount entered
  cout<<"Quarters: "<<a<<endl;
  cout<<"Dimes: "<<c<<endl;
  cout<<"Nickles: "<<b<<endl;
  cout<<"Pennies: "<<e<<endl;

  
  //getting the total before adding the fee
  total=h+i+j+k;
  
  fee=total*.07;
  cout<<"Total: $"<<total<<endl;

  cout<<"Fee: $"<<fee<<endl;
  
  payout=total-fee;
  cout<<"Payout: $"<<payout<<endl;
  
  
  return 0;//always return 0. Proves that your program went through properly
}  
